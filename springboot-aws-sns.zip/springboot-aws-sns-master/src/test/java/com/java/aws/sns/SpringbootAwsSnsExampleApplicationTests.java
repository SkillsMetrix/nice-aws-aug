package com.java.aws.sns;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootAwsSnsExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
